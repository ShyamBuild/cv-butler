# DEVLOG - goal, wrong, fix, evidence (one entry per green commit; newest last)
- v85.99 FAIL-LOUD: guards could fail silent. Wrong: wrapper appended at module end could never reach ck, which is born inside _selftest. Fix v85.101: confession printed inside the local ck; tombstone carries the witness at the empty tail seat. Evidence 80eff91 / mirror c456258.
- v85.100 ROLLED BACK: col-0 fixture block inserted before an indented ck line closed _selftest mid-body; selftest returned False with no output. Lesson: match anchor indent (P.ind); silent death = look for a closed block (law recorded v85.101).
- v85.101 pure naming brain + fixtures in gate + FAIL-LOUD relocated. Wrong: preflight lost # FAIL-LOUD v85.99 because deletion removed the only witness. Fix: tombstone line carries it. Evidence 80eff91.
- v85.102/v85.103 delegation + mirror-safe counting. Wrong: S447 counted its own def-literal (census 2 vs ==1) and S448 demanded a marker prefix it did not carry. Fix: probes spelled in concatenated pieces; halves never ship again. Evidence b378b23 / 628eccf.
- v85.104 right-click gated deed restored. Wrong earlier: propose-only law over-cut and disarmed the master's own gesture. Fix: deed returns behind identity gate, twin refusal, collision check. Evidence 59c6abc.
- v85.105/106/107 ink eye. Wrong: unguarded _pdf_pure_text crash blinded the OCR eye (PURE-ARMOR); the sips png detour fed a PDF-only Swift binary pictures it could not open (raster retired); caches served stale silences (rebirths). Evidence a8aaa6b, 033444b.
- v85.108/109/110 sweep garbage deed + MAIL-REFUSE + HEAD-SCOPE + STOP-EXT3 + DIAG-EVERY-CLICK. Wrong: fixtures caught an email token wearing a name coat and title-case skill/language pairs posing as people. Fix: three refusals, fixture-pinned. Evidence 4503e18.
- v85.111/85.112 EMAIL-ANCHOR + cache bump. Wrong: empty laps shipped green because anchors matched comment text rewritten by a parallel session (v85.113-126: layout eye, OCR patience, initial anchor). Fix: law 10 READ-BEFORE-PATCH + empty done-list crashes. Evidence bb65baf, 52ab54d.
- v85.123 FIRST-LINE-MONONYM + re-seated anchor. Wrong first run: guard probed '# re-seated v85.123' while comment wrote '(re-seated v85.123)'. Fix: witness and guard spell the marker identically. Evidence 4e93f91.
- v85.124 MONO-DOOR: the eye gate accepted one-word names the brain witnessed (2 <= became 1 <=). Wrong first paste: apostrophe inside a single-quoted string killed the note at parse time. Fix: reworded comment. Acceptance: jghhjghg.pdf -> Ajay.pdf, diag eye-head Ajay. Evidence c2eb23a / mirror 138e978.
- v85.125 CASEBOOK attempted: empty lap (comment anchor rotted). Re-seated in v85.127 on the code format-string anchor.
- v85.126 rulebook + devlog + dashboard + snapshot ritual land, so every future hand inherits the memory.
## FAILURE TAXONOMY (read before debugging): silent death with no traceback = closed block or swallowed SystemExit (use exec + traceback catch); empty done-list = rotted anchor (read live book); FAIL WHY prints the probe line = mirror trap or wrong conjunct; preflight lost marker = deletion without tombstone; syntax error at an except = indent law; green but behaviour unchanged = cache version not bumped.
## ONE-CHARACTER DEATHS: indent (v85.100), hash vs paren (v85.123), apostrophe (v85.124). Respect the character.
- v85.127 1ceaa40: casebook seated after two anchor deaths (comment rot, then an emoji inside the quotes); S467 pins it.
- v85.128 7727b06: FOLDERS.md lands (map + before/after sync ritual + mirror gotchas); rulebook gains rule 15.
- v85.129 db76731: TWO-WAY DOOR lands; session-B lessons credited and taken forward; HANDOFF letter opened.

## PARALLEL DESK RETROSPECTIVE (v85.113-v85.126) - reconstructed by the architect at v85.129-130 from mirror markers and diffs; provenance is evidence, not their notes, because they left none - which is why rules 16 and 17 now exist.
- v85.113 EMAIL-ANCHOR-INITIAL: deep title-case names anchored by the email initial; guard numbered S462 (duplicate).
- v85.114 OCR-PATIENT: ink eye timeout 25s to 90s; cold Vision starts no longer read as silence.
- v85.117 CASE-GATE: garbage stems skip the display-name case-fix, so the FIRST click goes straight to the eyes.
- v85.118 WAKE-DRAIN: rename wakes ride the service door on the next tick - the file-change trigger the master asked for.
- v85.121 SERVICE-LAYOUT-EYE: get_visual_name fallback reads separated visual CV headers after text/OCR eyes.
- v85.124 SUMMARY-AUTO; v85.125 WITNESS-FALLBACK + OCR-CACHE; v85.126 VISION-ONLY: a text layer with no witness falls back to ink once, cached by inode and version.
- Tuition for both desks: laps shipped without DEVLOG entries force the next hand to re-derive traps from markers; rules 16 and 17 close that forever.
