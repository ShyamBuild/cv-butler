# DASHBOARD - live state, versions, debts, in-flight (update after every green commit)
Live: v85.127 1ceaa40 (casebook live; rename goal achieved and recorded)
In-flight: none - queue: Rakesh teach-schema (consent pending), pure-text regex fix, guard renumber
| version | local | mirror | state | summary |
| v85.101 | 80eff91 | c456258 | proven | pure brain, fixtures in gate, FAIL-LOUD in local ck |
| v85.103 | b378b23 | 628eccf | proven | delegation + mirror-safe counting + S441 trio |
| ci | 9bbe250 | 019f433/8a59460 | proven | gate.yml on mirror; deps fix |
| v85.106 | a8aaa6b | a60bef3 | proven | PURE-ARMOR |
| v85.107 | 033444b | 8c7d6e8 | proven | raster retired, ink eye whole |
| v85.109 | 4503e18 | 9c4e090 | proven | MAIL-REFUSE, HEAD-SCOPE, STOP-EXT3 |
| v85.111 | bb65baf | e871491 | proven | EMAIL-ANCHOR |
| v85.124 | c2eb23a | 138e978 | LIVE | MONO-DOOR, Ajay acceptance |
DEBTS: pure-text regex unbalanced-paren (armored, unfixed); twin kjhgjkhjhj.pdf collision awaits master; Rakesh teach-schema (email beside digits) awaits consent; guard numbers S462-S464 duplicated across parallel sessions (cosmetic, renumber someday); casebook writer re-seat.

Shared surfaces (read all before, write all after): DEVLOG.md, DASHBOARD.md, FOLDERS.md, LESSONS.md, HANDOFF.md, casebook.jsonl.

Other desk: parallel laps v85.113-126 reconstructed in DEVLOG at v85.129-130; from v85.129 on EVERY hand owes DEVLOG + HANDOFF (rules 16-17); the architect chat reads them at session open.
